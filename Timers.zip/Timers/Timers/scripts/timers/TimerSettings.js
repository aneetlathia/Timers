define(["require", "exports", "./BeepTimerModule"], function (require, exports, BeepTimerModule) {
    "use strict";
    var BeepTimer = BeepTimerModule.BeepTimer;
    function setScreenTimeoutTimer() {
        return new BeepTimer(170, 3);
    }
    exports.setScreenTimeoutTimer = setScreenTimeoutTimer;
    function setQuickTimer() {
        return new BeepTimer(30, 2);
    }
    exports.setQuickTimer = setQuickTimer;
});
//# sourceMappingURL=TimerSettings.js.map
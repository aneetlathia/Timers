﻿//require(["./Shapes4"], function (shapess4) {

//    // Note: shappes4 is used instead of shapes4, because the name of variable in the function parameter must not be the
//    // same name as the external module.
//    var shape1 = new shapess4.Heptagon();
//    var shape2 = new shapess4.Octagon();

//    shape1.showShapeName();
//    shape2.showShapeName();
//});

require(["/scripts/timers/BeepTimerModule", "/scripts/timers/TimerSettings"], (beepTimerMod, timerSettingsMod) => {

    var beepTimerRunner = new beepTimerMod.BeepTimerModule(timerSettingsMod.setQuickTimer());

    beepTimerRunner.start();
});
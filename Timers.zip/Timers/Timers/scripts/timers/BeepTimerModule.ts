﻿declare var $: JQueryStatic;

export interface IBeepTimer {

    waitTimesInSeconds: number;
    numOfBeeps: number;
    longBeeps: boolean;
}

export class BeepTimer implements IBeepTimer {

    constructor(public waitTimesInSeconds: number, public numOfBeeps: number = 1, public longBeeps: boolean = false) { }
}

export interface IBeepTimerRunner {

    start(): void;
    stop(): void;
}

export class BeepTimerRunner implements IBeepTimerRunner {

    constructor(beepTimer: IBeepTimer) {

        this.beepTimer = beepTimer;
    }

    private beepTimer: IBeepTimer;
    private laspedSeconds: number;
    private timer: any;

    start(): void {

        this.laspedSeconds = -1;
        this.timer = setInterval(() => {

            this.laspedSeconds++;
            console.log(this.laspedSeconds);

            if (this.laspedSeconds === this.beepTimer.waitTimesInSeconds) {

                this.stop();
                this.beep(this.beepTimer.numOfBeeps, this.beepTimer.longBeeps);
            }
        }, 1000);
    }

    stop(): void {

        clearInterval(this.timer);
    }

    private beep(numOfBeeps: number, longBeeps: boolean) : void {

        var msg: string = "";

        for (var indx: number = 0; indx < numOfBeeps; indx++) {

            msg = msg + "Beep! ";
        }

        alert(msg);
    }
}

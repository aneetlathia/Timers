﻿import BeepTimerModule = require("./BeepTimerModule");
import BeepTimer = BeepTimerModule.BeepTimer;

export function setScreenTimeoutTimer(): BeepTimer {

    return new BeepTimer(170, 3);
}

export function setQuickTimer(): BeepTimer {

    return new BeepTimer(30, 2);
}

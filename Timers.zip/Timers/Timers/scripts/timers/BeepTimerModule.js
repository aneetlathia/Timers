define(["require", "exports"], function (require, exports) {
    "use strict";
    var BeepTimer = (function () {
        function BeepTimer(waitTimesInSeconds, numOfBeeps, longBeeps) {
            if (numOfBeeps === void 0) { numOfBeeps = 1; }
            if (longBeeps === void 0) { longBeeps = false; }
            this.waitTimesInSeconds = waitTimesInSeconds;
            this.numOfBeeps = numOfBeeps;
            this.longBeeps = longBeeps;
        }
        return BeepTimer;
    }());
    exports.BeepTimer = BeepTimer;
    var BeepTimerRunner = (function () {
        function BeepTimerRunner(beepTimer) {
            this.beepTimer = beepTimer;
        }
        BeepTimerRunner.prototype.start = function () {
            var _this = this;
            this.laspedSeconds = -1;
            this.timer = setInterval(function () {
                _this.laspedSeconds++;
                console.log(_this.laspedSeconds);
                if (_this.laspedSeconds === _this.beepTimer.waitTimesInSeconds) {
                    _this.stop();
                    _this.beep(_this.beepTimer.numOfBeeps, _this.beepTimer.longBeeps);
                }
            }, 1000);
        };
        BeepTimerRunner.prototype.stop = function () {
            clearInterval(this.timer);
        };
        BeepTimerRunner.prototype.beep = function (numOfBeeps, longBeeps) {
            var msg = "";
            for (var indx = 0; indx < numOfBeeps; indx++) {
                msg = msg + "Beep! ";
            }
            alert(msg);
        };
        return BeepTimerRunner;
    }());
    exports.BeepTimerRunner = BeepTimerRunner;
});
//# sourceMappingURL=BeepTimerModule.js.map